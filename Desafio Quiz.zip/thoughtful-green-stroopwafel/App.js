import React, { useState } from 'react';
// 1. IMPORTAMOS O COMPONENTE IMAGE AQUI:
import { View, Text, TouchableOpacity, ActivityIndicator, StyleSheet, Image } from 'react-native';
const QUIZ = [
{
id: 1,
pergunta: 'Quem fundou Konoha?',
opcoes: ['Hashirama e Madara', 'Os Clãs', 'Kaguya', 'Naruto e Sasuke'],
respostaCerta: 0,
imagem: 'https://i.pinimg.com/736x/b1/71/ec/b171ec6c19523d1ee836cd2900af5893.jpg'
},

{
id: 2,
pergunta: 'Quem criou o rasegan?',
opcoes: ['Tobirama', 'Kakashi', 'Minato', 'Hagoromo'],
respostaCerta: 2,
imagem: 'https://fwmedia.fandomwire.com/wp-content/uploads/2026/01/27134103/naruto-minato-namikaze.jpg'
},

{
id: 3,
pergunta: 'Qual clã é o do Tobirama?',
opcoes: ['Uchiha', 'Uzumaki', 'Hyuga', 'Senju'],
respostaCerta: 3,
imagem:'https://www.einerd.com/wp-content/uploads/2020/11/Tobirama-Senju-Naruto-capa.jpg'
},

{
id: 4,
pergunta: 'Qual o jutsu que o Naruto não sabia como usar perfeitamente no começo do anime?',
opcoes: ['Chidori', 'Jutsu Sexy', 'Clone das Sombras', 'Edo Tensei'],
respostaCerta: 2,
imagem:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRy3RTGMubpsXd6trRDyLDTmcMMAaz-wvod8A&s'
},

{
id: 5,
pergunta: 'Quem ensinou o rasegan pro Naruto?',
opcoes: ['Kakashi', 'Jiraya', 'Iruka', 'Pain'],
respostaCerta: 1,
imagem: 'https://criticalhits.com.br/wp-content/uploads/2020/08/rasengan-01-e1574988225133.jpg'
},

{
id: 6,
pergunta: 'O que acontece quando o usuário usa Mangekyou Sharingan em excesso?',
opcoes: ['Fica mais rápido', 'Perde o mangekyou', 'Fica temporariamente sem chakra', 'Começa perder a visão'],
respostaCerta: 3,
imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRXqB4Lp7kfKyjxeBaLsSLFJ6Nk8fMx44YbYw&s'
},

{
id: 7,
pergunta: 'O que significa Akasuki?',
opcoes: ['Alvorecer', 'Amanhecer', 'Amanhã', 'Nada'],
respostaCerta: 1,
imagem: 'https://preview.redd.it/who-is-your-favorite-akatsuki-member-and-why-v0-53nani279wia1.jpg?width=640&crop=smart&auto=webp&s=46bfc04040dc97b5ccc316f6161d34d9a6fe185a'
},

{
id: 8,
pergunta: 'Qual é o NOME do Tio do lámen?',
opcoes: ['Ichiraku', 'Fukasaku', 'Teuchi', 'Zoro'],
respostaCerta: 2,
imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpEhCdBqPnfQI_Kg_gyachWlRZjPXRzvmSSw&s'
},

{
id: 9,
pergunta: 'Quem foi a primeira escolha para se tornar 5° Hokage?',
opcoes: ['Jiraya', 'Tsunade', 'Kakashi', 'Naruto'],
respostaCerta: 0,
imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXPz1zdwXjg6rT2q6nyK4qoNERAxHDYSgQcA&s'
},

{
id: 10,
pergunta: 'É 106',
opcoes: ['Tenten', 'Hinata', 'Sakura', 'Tsunade'],
respostaCerta: 3,
imagem: 'https://i.redd.it/do-you-think-kakashi-was-starstruck-when-meeting-jiraya-for-v0-0ewclkz2vs4f1.jpg?width=602&format=pjpg&auto=webp&s=21c94e7e8201e38196f2c58a06dc93b7768f938f'
},

];
export default function AppQuiz() {
const [telaAtual, setTelaAtual] = useState('inicio');
const [perguntaAtual, setPerguntaAtual] = useState(0);
const [pontuacao, setPontuacao] = useState(0);
const [carregando, setCarregando] = useState(false);
const [opcaoSelecionada, setOpcaoSelecionada] = useState(null);



function iniciarJogo() {
setPerguntaAtual(0);
setPontuacao(0);
setTelaAtual('quiz');
}


function voltarAoInicio() {
setTelaAtual('inicio');
}


function responder(indiceClicado) {
  setOpcaoSelecionada(indiceClicado);

  const pergunta = QUIZ[perguntaAtual];
  if (indiceClicado === pergunta.respostaCerta) {
    setPontuacao(pontuacao + 1);
  }

  setTimeout(() => {
    setCarregando(true);
    setTimeout(() => {
      if (perguntaAtual + 1 < QUIZ.length) {
        setPerguntaAtual(perguntaAtual + 1);
      } else {
        setTelaAtual('resultado');
      }
      
      setOpcaoSelecionada(null);
      setCarregando(false);
    }, 1500);

  }, 1000);
}

// ==========================================
// AS TELAS
// ==========================================
if (telaAtual === 'inicio') {
return (
<View style={styles.telaCentrada}>
{/* 2. EXEMPLO PRÁTICO DE IMAGEM: */}
{/* Repare nas chaves duplas {{ }} usadas para passar o link da internet */}


<Image
source={{ uri: 'https://animeflix.com.br/wp-content/uploads/2025/02/Animes-fas-de-Naruto.jpg' }}
style={styles.logoInicial}
/>


<Text style={styles.tituloPrincipal}>Quiz do Naruto</Text>
<Text style={styles.subtituloInicio}>Teste seus conhecimentos em Naruto!</Text>
<TouchableOpacity style={styles.botaoIniciar} onPress={iniciarJogo} activeOpacity={0.8}>
<Text style={styles.textoBotaoIniciar}>INICIAR JOGO</Text>
</TouchableOpacity>
</View>
);
}

if (telaAtual === 'resultado') {
return (
<View style={styles.telaCentrada}>
<Text style={styles.iconeGrande}> </Text>
<Text style={styles.titulo}>Fim de Jogo!</Text>
<Text style={styles.subtitulo}>Você acertou {pontuacao} de {QUIZ.length} perguntas.</Text>
<TouchableOpacity style={styles.botaoAcao} onPress={voltarAoInicio} activeOpacity={0.8}>
<Text style={styles.textoBotaoAcao}>Voltar ao Início</Text>
</TouchableOpacity>
</View>
);
}

if (carregando) {
return (
<View style={styles.telaCentrada}>
<ActivityIndicator size="large" color="#3b82f6" />
<Text style={styles.textoCarregando}>Validando resposta...</Text>
</View>
);
}

const pergunta = QUIZ[perguntaAtual];
return (
<View style={styles.tela}>
<View style={styles.cabecalho}>
<Text style={styles.progresso}>Pergunta {perguntaAtual + 1} de {QUIZ.length}</Text>
<Text style={styles.pontos}>Pontos: {pontuacao}</Text>
</View>

<View style={styles.cartaoPergunta}>
  <Image 
    source={{ uri: pergunta.imagem }} 
    style={styles.imagemPergunta} 
  />
  <Text style={styles.textoPergunta}>{pergunta.pergunta}</Text>
</View>

<View style={styles.areaOpcoes}>
{pergunta.opcoes.map((opcao, index) => {
  const foiClicado = index === opcaoSelecionada;
  const ehCorreto = index === pergunta.respostaCerta;
  return (
    <TouchableOpacity
      key={index}
      disabled={opcaoSelecionada !== null}
      style={[
        styles.botaoOpcao,
        foiClicado && { backgroundColor: ehCorreto ? '#22c55e' : '#ef4444' }
      ]}
      onPress={() => responder(index)}
      activeOpacity={0.7}
    >
      <Text style={styles.textoOpcao}>{opcao}</Text>
    </TouchableOpacity>
  );
})}



</View>
</View>
);
}
// ==========================================
// ESTILOS
// ==========================================
const styles = StyleSheet.create({
tela: { flex: 1, backgroundColor: 'white', padding: 20, paddingTop: 60 },
telaCentrada: { flex: 1, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center', padding: 20 },
// 3. ESTILO DA IMAGEM


logoInicial: { width: 300, height: 300, marginBottom: 80 },
tituloPrincipal: { fontSize: 36, fontWeight: '900', color: '#1e293b', marginBottom: 10, textAlign: 'center' },


subtituloInicio: { fontSize: 16, color: '#64748b', marginBottom: 50, textAlign: 'center', paddingHorizontal: 20 },


botaoIniciar: { backgroundColor: '#10b981', paddingVertical: 20, paddingHorizontal: 40, borderRadius: 20, width: '100%', maxWidth: 300, shadowColor: '#10b981', shadowOpacity: 0.4, shadowRadius: 15, elevation: 8, alignItems: 'center' },


textoBotaoIniciar: { color: 'white', fontSize: 20, fontWeight: '900', letterSpacing: 1 },
cabecalho: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30, paddingHorizontal: 10 },


progresso: { fontSize: 16, fontWeight: '700', color: '#64748b' },
pontos: { fontSize: 16, fontWeight: '800', color: '#3b82f6' },


cartaoPergunta: { backgroundColor: 'white', padding: 30, borderRadius: 20, marginBottom: 30, shadowColor: '#0f172a', shadowOpacity: 0.05, shadowRadius: 15, elevation: 5, minHeight: 150, justifyContent: 'center' },


textoPergunta: { fontSize: 22, fontWeight: '800', color: '#1e293b', textAlign: 'center', lineHeight: 30 },

imagemPergunta: {
  width: '100%',
  height: 200,
  borderRadius: 8,
  marginBottom: 15
},


areaOpcoes: { flex: 1 },

botaoOpcao: { backgroundColor: 'white', padding: 20, borderRadius: 15, marginBottom: 15, borderWidth: 2, borderColor: '#e2e8f0' },

textoOpcao: { fontSize: 18, color: '#334155', fontWeight: '600', textAlign: 'center' },

iconeGrande: { fontSize: 80, marginBottom: 20 },

titulo: { fontSize: 32, fontWeight: '900', color: '#0f172a', marginBottom: 10 },

subtitulo: { fontSize: 18, color: '#64748b', marginBottom: 40 },

botaoAcao: { backgroundColor: '#3b82f6', paddingVertical: 18, paddingHorizontal: 40, borderRadius: 16, width: '100%', maxWidth: 300, alignItems: 'center' },


textoBotaoAcao: { color: 'white', fontSize: 18, fontWeight: '800' },


textoCarregando: { marginTop: 20, fontSize: 18, fontWeight: '600', color: '#3b82f6' }
});